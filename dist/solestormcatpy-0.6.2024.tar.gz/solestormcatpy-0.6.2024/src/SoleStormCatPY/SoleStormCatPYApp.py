import sscPyStandalone as s
s.fullPythonApp()
