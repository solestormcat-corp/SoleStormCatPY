# MathSolver
"MathSolver" seems just like it sounds. A calculator. A boring old calculator. You've seen many apps (the even come built in to your device) that work like this, but "MathSolver" is made to help with your daily math needs. "MathSolver" can do math ranging from Multiplication, Division, Adding, Subtracting, and Square Root!

## How To Use
To Run "MathSolver" in your script, make sure to specify `num1` (Being the first number), `num2` (being your second number), and `ty` (being the type of math you require), along with the command `SoleStormCatPY.MathSolver.numPrint(num1, num2, ty)`.

You may also run `SoleStormCatPY.MathSolver.numPrint('5','8','Divide')` when running MathSolver!

Have Fun Mathing!