# GreeNotes
`GreeNotes` is an application that allows users to write (or read) reminders that they make. This app writes a file named `.sscGreeNotes` file to the local computer, and nothing gets uploaded online. You can even read/write your reminders from this file!

## How To Use
There are 2 ways to run `GreeNotes`, but both require interactions with the terminal. To run this application (the main method), use `import SoleStormCatPY.GreeNotes` and `SoleStormCatPY.GreeNotes.GreeNotes()` in the terminal. The other way is to run SoleStormCatPY GUI application, then change the tab to `Terminal Apps`, then click on `GreeNotes (Terminal)`.
