# SystemInfo
This application prints out the user's infomation onto their terminal screen. Here is a basic output of this application:

`The Current User OS is:`
`Linux`

`The Current User is:`
`root`

`The Current Version of Python is:`
`Python 3.10.6`

`The Current Wifi is:`
`MyWifiNetwork`

## How To Use
Here is how you use "SystemInfo":

`import SoleStormCatPY.SystemInfo as SystemInfo`
`SystemInfo.systemPrint()`
