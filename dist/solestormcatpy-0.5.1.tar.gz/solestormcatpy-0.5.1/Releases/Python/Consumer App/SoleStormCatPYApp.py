"""This is the app made for consumers. It'll only run GUI applications."""
"""This standalone module requires a version of Python installed on the client's machine"""

import SoleStormCatPY.sscPyStandalone as sscPY

sscPY.fullPythonApp()
